package edu.rosehulman.moviequotes

object Constants {
    const val TAG = "MQ"
}