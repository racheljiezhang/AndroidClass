package edu.rosehulman.examonezhangrj

class Coordinate {
    var x: Int = 4;
    var y: Int = 4;

    fun xup(){
        this.x++
    }

    fun xdown(){
        this.x--
    }

    fun yup(){
        this.y++
    }

    fun ydown(){
        this.y--
    }

}