package edu.rosehulman.moviequotes2.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.get
import androidx.navigation.fragment.findNavController
import androidx.navigation.navOptions
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import edu.rosehulman.moviequotes2.R
import edu.rosehulman.moviequotes2.model.MovieQuote
import edu.rosehulman.moviequotes2.model.MovieQuoteViewModel
import edu.rosehulman.moviequotes2.ui.QuotesListFragment

class MovieQuoteAdpter(val fragment: QuotesListFragment) : RecyclerView.Adapter<MovieQuoteAdpter.MovieQuoteViewHolder>() {
    val model = ViewModelProvider(fragment.requireActivity()).get(MovieQuoteViewModel::class.java)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieQuoteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row_quote, parent, false)
        return MovieQuoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieQuoteViewHolder, position: Int) {
        holder.bind(model.getQuoteAt(position))
    }

    fun addListener(fragmentName: String){
        model.addListener(fragmentName){
            notifyDataSetChanged()
        }
    }

    fun removeListener(fragmentName: String) {
        model.removeListener(fragmentName)
    }
    override fun getItemCount() = model.size()

    fun addQuote(movieQuote: MovieQuote?) {
        model.addQuote(movieQuote)
        notifyDataSetChanged()
    }


    inner class MovieQuoteViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val quoteTextView: TextView = itemView.findViewById(R.id.row_quote_text_view)
        val movieTextView: TextView = itemView.findViewById(R.id.row_movie_text_view)

        init {
            itemView.setOnClickListener{
                model.updatePos(adapterPosition)
                fragment.findNavController().navigate(R.id.navigation_quotes_edit,
                    null,
                navOptions{

                    anim{
                        enter = android.R.anim.slide_in_left
                        exit = android.R.anim.slide_out_right
                    }
                    }
                )
            }
            itemView.setOnLongClickListener{
                model.updatePos(adapterPosition)
                model.toggleCurrentQuote()
                notifyItemChanged(adapterPosition)
                true
            }

        }


        fun bind(movieQuote: MovieQuote){
            quoteTextView.text = movieQuote.quote
            movieTextView.text = movieQuote.movie
            itemView.setBackgroundColor(
                if(movieQuote.isSelected){
                    Color.GREEN
                }else{
                    Color.WHITE
                }
            )
        }
    }
}