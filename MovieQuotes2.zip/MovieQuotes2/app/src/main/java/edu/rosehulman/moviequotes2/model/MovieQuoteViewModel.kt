package edu.rosehulman.moviequotes2.model

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import edu.rosehulman.moviequotes2.Constants
import edu.rosehulman.moviequotes2.model.MovieQuote
import kotlin.random.Random


class MovieQuoteViewModel : ViewModel() {
    var movieQuotes = ArrayList<MovieQuote>()
    var currentPos = 0

    val ref = Firebase.firestore.collection(MovieQuote.COLLECTION_PATH)

    fun getQuoteAt(pos: Int) = movieQuotes[pos]

    fun getCurrentQuote() = getQuoteAt(currentPos)


    fun addQuote(movieQuote: MovieQuote?){
        val random = getRandom()
        val newQuote = movieQuote ?: MovieQuote("quote$random", "movie$random")
        ref.add(newQuote)
    }
    var subscriptions = HashMap<String, ListenerRegistration>()

    fun addListener(fragmentName: String, observer: ()-> Unit){
        val subscription = ref
            .orderBy(MovieQuote.CREATED_KEY, Query.Direction.ASCENDING)
            .addSnapshotListener{ snapshot: QuerySnapshot?, error: FirebaseFirestoreException? ->
            error?.let {
                Log.d(Constants.TAG, "Error: $error")
                return@addSnapshotListener
            }
            movieQuotes.clear()
            snapshot?.documents?.forEach {
                movieQuotes.add(MovieQuote.from(it))
            }

            observer()
        }
        subscriptions[fragmentName] = subscription
    }

    fun removeListener(){
        ref.document(getCurrentQuote().id).delete()
        currentPos = 0
    }

    fun updateCurrentQuote(quote: String, movie: String){
        movieQuotes[currentPos].quote = quote
        movieQuotes[currentPos].movie = movie
        ref.document(getCurrentQuote().id).set(getCurrentQuote())
//        ref.document(getCurrentQuote().id).update() if you want to overwrite specific fields.

    }
    fun removeListener(fragmentName: String){
        subscriptions[fragmentName]?.remove()   //tells firebase to stop listening
        subscriptions.remove(fragmentName)  //removes from map
    }

    fun removeCurrentQuote(){
        ref.document(getCurrentQuote().id).delete()
        currentPos = 0
    }
    fun updatePos(pos: Int){
        currentPos = pos
    }
    fun size() = movieQuotes.size

    fun getRandom() = Random.nextInt(100)

    fun toggleCurrentQuote() {
        movieQuotes[currentPos].isSelected = !movieQuotes[currentPos].isSelected
    }


}