package edu.rosehulman.moviequotes2

object Constants {
    const val TAG = "MQ"
}